import 'dart:async';
import 'package:flutter/material.dart';

void main() {
  runApp(const ThreadSpaceApp());
}

class ThreadSpaceApp extends StatelessWidget {
  const ThreadSpaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF6C63FF), // eto yung taga gawa nung colored box na ilalagay yung name ng user, kung ilang following, etc.
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedPage = "Home"; // Either Home or Topic
  String selectedTopic = "Technology"; // Current topic
  String currentTime = ""; // Live time string
  Timer? timer;
  // eto yung nag didisplay ng topics/thread na cliniclick mo

  final String profileImage = "https://i.pravatar.cc/150?img=3";
  final String username = "Username";
  // yung profile ni user sa taas ng burger button

  @override
  void initState() {
    super.initState();
    _updateTime();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateTime();
    });
  } // taga update ng time

  void _updateTime() {
    final now = DateTime.now();
    int hour = now.hour;
    String period = hour >= 12 ? "PM" : "AM";
    hour = hour % 12;
    hour = hour == 0 ? 12 : hour;

    setState(() {
      currentTime =
          "$hour:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')} $period";
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  final List<Map<String, dynamic>> topics = [
    {"name": "Technology", "icon": Icons.computer},
    {"name": "Gaming", "icon": Icons.sports_esports},
    {"name": "Music", "icon": Icons.music_note},
    {"name": "Science", "icon": Icons.science},
  ]; //nag set ng name sa baba topics

  final List<Map<String, dynamic>> homePosts = [ //laman ng home page
  {
    "user": "GlobalUser",
    "time": "1h ago",
    "title": "Welcome to Home Feed",
    "content":
        "This is the general explore feed similar to Twitter or Facebook.",
    "votes": 56,
    "comments": 10,
    "flair": "General",
    "image": "https://picsum.photos/600/300?10"
  },
  {
    "user": "Traveler",
    "time": "3h ago",
    "title": "Beautiful sunset 🌇",
    "content": "Captured this amazing sunset while traveling. Nature never disappoints.",
    "votes": 102,
    "comments": 21,
    "flair": "Lifestyle",
    "image": "https://picsum.photos/600/300?11"
  },
  {
    "user": "Foodie123",
    "time": "2h ago",
    "title": "Best homemade pizza",
    "content": "Just made my first homemade pizza! 🍕 What toppings do you prefer?",
    "votes": 75,
    "comments": 12,
    "flair": "Food",
    "image": "https://picsum.photos/600/300?12"
  },
  {
    "user": "NatureLover",
    "time": "30m ago",
    "title": "Hiking Adventures",
    "content":
        "Explored a new trail today and the view was breathtaking. Highly recommend visiting if you can!",
    "votes": 88,
    "comments": 15,
    "flair": "Travel",
    "image": "https://picsum.photos/600/300?13"
  },
  {
    "user": "MusicFan",
    "time": "5h ago",
    "title": "Favorite songs of 2026",
    "content":
        "Sharing my top 5 tracks of the year so far. What are yours?",
    "votes": 65,
    "comments": 8,
    "flair": "Music",
    "image": "https://picsum.photos/600/300?14"
  },
  {
    "user": "TechGeek",
    "time": "3h ago",
    "title": "AI trends this month",
    "content":
        "The latest AI research has been incredible! Check out the new GPT-based tools.",
    "votes": 110,
    "comments": 20,
    "flair": "Tech",
    "image": "https://picsum.photos/600/300?15"
  },
  {
    "user": "FitnessAddict",
    "time": "2d ago",
    "title": "Morning workouts",
    "content":
        "I started a new morning routine and feel more energized. Who else loves early workouts?",
    "votes": 45,
    "comments": 5,
    "flair": "Fitness",
    "image": "https://picsum.photos/600/300?16"
  },
  {
    "user": "ArtLover",
    "time": "6h ago",
    "title": "My new painting",
    "content":
        "Tried a new watercolor technique today. What do you think of the result?",
    "votes": 50,
    "comments": 10,
    "flair": "Art",
    "image": "https://picsum.photos/600/300?17"
  },
  {
    "user": "BookWorm",
    "time": "1h ago",
    "title": "Current reads",
    "content":
        "Just finished reading a fantastic sci-fi novel. Any recommendations for my next read?",
    "votes": 32,
    "comments": 4,
    "flair": "Books",
    "image": "https://picsum.photos/600/300?18"
  },
  {
    "user": "CoderLife",
    "time": "45m ago",
    "title": "Debugging struggles",
    "content":
        "Spent 3 hours debugging a simple bug. Can anyone relate? 😂",
    "votes": 90,
    "comments": 14,
    "flair": "Coding",
    "image": "https://picsum.photos/600/300?19"
  },
  {
    "user": "MovieBuff",
    "time": "2h ago",
    "title": "Best movie of the month",
    "content": "Watched an amazing film last night. Would definitely recommend it to everyone!",
    "votes": 70,
    "comments": 12,
    "flair": "Movies",
    "image": "https://picsum.photos/600/300?20"
  },
];

  final Map<String, List<Map<String, dynamic>>> topicPosts = { //laman nung threads sa topics
    "Technology": [
      {
        "user": "TechGuru",
        "time": "2h ago",
        "title": "Flutter 4.0 Changes Everything",
        "content":
            "Flutter 4.0 introduces major rendering improvements. Performance gains are noticeable especially in complex layouts.",
        "votes": 120,
        "comments": 24,
        "flair": "Update",
        "image": "https://picsum.photos/600/300?1"
      },
    ],
    "Gaming": [
      {
        "user": "ProGamer",
        "time": "4h ago",
        "title": "Best RPG of 2026?",
        "content":
            "What do you think is the best RPG released this year? I'm torn between a few titles.",
        "votes": 78,
        "comments": 15,
        "flair": "Discussion",
        "image": "https://picsum.photos/600/300?2"
      },
    ],
    "Music": [
      {
        "user": "BeatMaker",
        "time": "1d ago",
        "title": "Indie Music Rising Again",
        "content":
            "Indie artists are taking over streaming platforms. What are your favorite indie tracks lately?",
        "votes": 45,
        "comments": 8,
        "flair": "Trend",
        "image": "https://picsum.photos/600/300?3"
      },
    ],
    "Science": [
      {
        "user": "AstroFan",
        "time": "3h ago",
        "title": "New Discovery in Space",
        "content":
            "Scientists discovered a potentially habitable exoplanet. What does this mean for humanity?",
        "votes": 210,
        "comments": 67,
        "flair": "News",
        "image": "https://picsum.photos/600/300?4"
      },
    ],
  };

  @override
  Widget build(BuildContext context) {
    final posts = selectedPage == "Home"
        ? homePosts
        : topicPosts[selectedTopic] ?? [];

    final today = DateTime.now();
    final formattedDate = "${today.day}/${today.month}/${today.year}"; // nag seset ng date

    return Scaffold(
      appBar: AppBar(
        title: Text(selectedPage == "Home" ? "Home" : selectedTopic),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
          PopupMenuButton<String>(
            icon: CircleAvatar(
              backgroundImage: NetworkImage(profileImage),
            ),
            itemBuilder: (context) => const [
              PopupMenuItem(value: "View Profile", child: Text("View Profile")),
              PopupMenuItem(value: "My Posts", child: Text("My Posts")),
              PopupMenuItem(
                  value: "Privacy Settings", child: Text("Privacy Settings")),
              PopupMenuItem(
                  value: "Account Settings", child: Text("Account Settings")),
              PopupMenuItem(value: "Logout", child: Text("Logout")),
            ], // eto yung nag papakita nung laman ng profile icon
          ),
          const SizedBox(width: 10),
        ],
      ),

      drawer: Drawer( 
        backgroundColor: const Color(0xFF1E1E1E),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(username),
              accountEmail: const Text("Following: 320 • Followers: 1,245"), // display ng info pag pindot sa burger icon
              currentAccountPicture: CircleAvatar(
                backgroundImage: NetworkImage(profileImage),
              ),
              decoration: const BoxDecoration(color: Color(0xFF6C63FF)),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text("Home"),
              selected: selectedPage == "Home",
              onTap: () {
                setState(() {
                  selectedPage = "Home";
                });
                Navigator.pop(context);
              },
            ),
            const Divider(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child:
                  Text("Topics", style: TextStyle(fontWeight: FontWeight.bold)), // taga gawa ng column ng topics
            ),
            ...topics.map((topic) => ListTile(
                  leading: Icon(topic["icon"]),
                  title: Text(topic["name"]),
                  selected:
                      selectedTopic == topic["name"] && selectedPage != "Home",
                  onTap: () {
                    setState(() {
                      selectedPage = "Topic";
                      selectedTopic = topic["name"];
                    });
                    Navigator.pop(context);
                  },
                )),
            const Divider(), //gumamit ng divider para mag ka line in between sa texts
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child:
                  Text("Trending", style: TextStyle(fontWeight: FontWeight.bold)), // taga gawa ng column ng trending
            ),
            const ListTile(
              leading: Icon(Icons.trending_up),
              title: Text("#Flutter"),
            ),
            const ListTile(
              leading: Icon(Icons.trending_up),
              title: Text("#AI"),
            ),
            const ListTile(
              leading: Icon(Icons.trending_up),
              title: Text("#Startups"),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.calendar_today),
              title: Text("Date: $formattedDate"),
            ),
            ListTile(
              leading: const Icon(Icons.access_time),
              title: Text("Time: $currentTime"),
            ),
          ],
        ),
      ),

      body: ListView.builder( // allows scrolling sa post?
        padding: const EdgeInsets.only(bottom: 80),
        itemCount: posts.length,
        itemBuilder: (context, index) {
          return _buildPostCard(posts[index]);
        },
      ),

      floatingActionButton: FloatingActionButton.extended( // "create post" button
        backgroundColor: const Color(0xFF6C63FF),
        onPressed: () {},
        icon: const Icon(Icons.add),
        label: const Text("Create Post"),
      ),
    );
  }

  Widget _buildPostCard(Map<String, dynamic> post) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), // taga gawa ng box ng posts
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              const Icon(Icons.arrow_upward),
              Text(post["votes"].toString()), //votes ng post na nakalagay na sa dynamic> homeposts
              const Icon(Icons.arrow_downward),
            ],
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("${post["user"]} • ${post["time"]}", // anong oras siya pinost and anong name ng user na nag post
                    style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                const SizedBox(height: 6),
                Text(post["title"], // name nung post
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                SizedBox(
                  height: 70,
                  child: SingleChildScrollView(
                    child: Text(post["content"]), // ano yung laman ng post
                  ),
                ),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.network(
                    post["image"], //image ng post
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.comment_outlined, size: 18),
                    const SizedBox(width: 4),
                    Text(post["comments"].toString()), //kung ilang comments meron sa post
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF6C63FF).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(post["flair"]), //flair = topic
                    ),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}