class WeatherModel {
  final String cityName;
  final double temperature;
  final String description;
  final int humidity;

    WeatherModel({
    required this.cityName,
    required this.temperature,
    required this.description,
    required this.humidity,
  });
   factory WeatherModel.fromJson(Map<String, dynamic> json) {
    return WeatherModel(
      cityName:    json['name'],
      temperature: json['main']['temp'].toDouble(),
      description: json['weather'][0]['description'],
      humidity:    json['main']['humidity'],
    );
  }
}

void main() {
  final w = WeatherModel(
    cityName: 'Manila',
    temperature: 31.5,
    description: 'clear sky',
    humidity: 78,
  );
  print(w.cityName);
  print(w.temperature);
}