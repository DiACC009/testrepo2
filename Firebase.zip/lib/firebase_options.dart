import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    throw UnsupportedError('Only web is supported on Zapp.run.');
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey:            'AIzaSyCDcD5-rmvuQmE2eEmHCdQy1Yu009E-pwE',
    appId:             '1:814994791355:web:8e9e37dfcd71f31d41c29e',
    messagingSenderId: '814994791355',
    projectId:         'todoappsample-eeea7',
    authDomain:        'todoappsample-eeea7.firebaseapp.com',
    storageBucket:     'todoappsample-eeea7.firebasestorage.app',
  );
}