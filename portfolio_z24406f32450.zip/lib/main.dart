import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
void main() {
  //starting point of every dart file
  runApp(const SimplePortfolioApp());
  //Flutter function that launch our application
  //Function - standalone block of code
  //Method - function that define w/in a class operates on objects data
  //MyApp() - your application 
}

class SimplePortfolioApp extends StatelessWidget {
  //Class name
  //const - doesn't change after building application
  const SimplePortfolioApp({Key? key}) :super(key: key);
  @override
  Widget build (BuildContext context) {
    return MaterialApp(
    debugShowCheckedModeBanner: false, //removees debug banner
    title: 'Portfolio',
     theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0x7393B3),
      ),
    home: HomePage(),
  );
  }
}
class HomePage extends StatefulWidget{
  const HomePage({Key? key}) : super(key: key);

@override
State<HomePage> createState() => _HomePageState();
/*State - return the objects
  State for the HomePage
  createState - Method
  _HomePageState() - hold data that can chage, trigger rebuild
  the application*/
}
  class _HomePageState extends State<HomePage>{
    String selectedPage = 'Home';
    late ScrollController _scrollController;
    
 @override
  void initState() {
    super.initState();
  _scrollController = ScrollController();
}
    
Widget _buildContent() {
  if (selectedPage == 'Home') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ClipOval(
          child: Image.asset(
            'lib/assets/images/profile.jpg', // sir yung mga images na trinay ko gawing profile lagpag 500kb di po maupload T-T
            width: 120,
            height: 120,
            fit: BoxFit.cover,
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Jester V. Rubia',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'BSCS Student',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }
  if (selectedPage == 'About') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: 16),
        Text(
          'This account is for school purposes only.',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'Im a student that is currently studying in STI College Caloocan',
          style: GoogleFonts.roboto(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }
    if (selectedPage == 'Skills') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: 16),
        Text(
          'Coming soon',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
   if (selectedPage == 'Contact') {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: 24),
        Text(
          'Contact number: 09915201341',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Socials: Jester V. Rubia',
          style: GoogleFonts.poppins(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
  return Text('Coming soon: $selectedPage');
}

 @override
  Widget build (BuildContext context){
  return Scaffold( /*page structure (holds appbar, drawer body*/
    backgroundColor: Color.fromARGB(204, 211, 211, 243),
    appBar: AppBar(
      leading: Builder(
        builder: (BuildContext context){
          return IconButton(
            icon: Icon(Icons.menu),
            onPressed: (){
              Scaffold.of(context).openDrawer();
            },
          );
        }
      ),
      title: Text('Portfolio',
      style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w600),
      ),
    ),

    drawer: Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration (
              color: Colors.blue,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text('Jester V. Rubia'),
                  SizedBox(height: 4),
                Text('BSCS Student'),
              ],
            ),
          ),
          
          ListTile(
  leading: Icon(Icons.home, color: Colors.blue),
  title: Text('Home'),
  onTap: () {
    Navigator.pop(context);
    setState(() {
      selectedPage = 'Home';
    });
  },
),
ListTile(
  leading: Icon(Icons.person, color: Colors.blue),
  title: Text('About'),
  onTap: () {
    Navigator.pop(context);
    setState(() {
      selectedPage = 'About';
    });
    
  },
),
ListTile(
  leading: Icon(Icons.lightbulb, color: Colors.blue),
  title: Text('Skills'),
  onTap: () {
    Navigator.pop(context);
    setState(() {
      selectedPage = 'Skills';
    });
  },
),
ListTile(
  leading: Icon(Icons.email, color: Colors.blue),
  title: Text('Contact'),
  onTap: () {
    Navigator.pop(context);
    setState(() {
      selectedPage = 'Contact';
    });
  },
),

Divider(),
ListTile(
  leading: Icon(Icons.download, color: Colors.blue),
  title: Text('Download Resume'),
  onTap: () {
    Navigator.pop(context);
    print('Download Resume tapped');
  },
),

        ],
      )
    ),
    
    
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children:  [
            ClipOval(
              child:
              Image.asset('lib/assets/images/',
              width: 120, height: 120, fit: BoxFit.cover),
              ),
            const SizedBox(height: 32),
            Text('Jester V. Rubia',
            style:GoogleFonts.poppins(
              fontSize: 24, fontWeight: FontWeight.bold
            ),
            ),
            const SizedBox(height: 8),
            Text('BSCS Student',
            style:GoogleFonts.poppins(
              fontSize: 15, fontWeight: FontWeight.bold, color: Colors.grey[600],
            ),
            ),
          ],
        )
    ),
    )
  );
}

   

  
 

@override
void dispose(){
  super.dispose();
}

}